"""
Model - 模型适配层
"""
from typing import List, Dict, Any
import aiohttp


class BaseModel:
    """模型基类"""
    
    def __init__(self, config: Dict):
        self.config = config
    
    async def chat(self, messages: List[Dict]) -> str:
        raise NotImplementedError


class MiniMaxModel(BaseModel):
    """MiniMax 模型"""
    
    def __init__(self, config: Dict):
        super().__init__(config)
        self.api_key = config.get("api_key", "")
        self.base_url = config.get("base_url", "https://api.minimax.chat/v1")
        self.model = config.get("model", "MiniMax-M2.5")
    
    async def chat(self, messages: List[Dict]) -> str:
        """发送聊天请求"""
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.7
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data, headers=headers) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    return result["choices"][0]["message"]["content"]
                else:
                    return f"API 错误: {resp.status}"


class OpenAIModel(BaseModel):
    """OpenAI 模型"""
    
    def __init__(self, config: Dict):
        super().__init__(config)
        self.api_key = config.get("api_key", "")
        self.base_url = config.get("base_url", "https://api.openai.com/v1")
        self.model = config.get("model", "gpt-4")
    
    async def chat(self, messages: List[Dict]) -> str:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": self.model,
            "messages": messages
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data, headers=headers) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    return result["choices"][0]["message"]["content"]
                else:
                    return f"API 错误: {resp.status}"


class MockModel(BaseModel):
    """模拟模型 - 用于测试"""
    
    async def chat(self, messages: List[Dict]) -> str:
        last_msg = messages[-1]["content"] if messages else ""
        
        responses = {
            "你好": "你好！我是玄灵AI，很高兴见到你！",
            "你是谁": "我是玄灵AI，一个智能 AI 助手。",
            "帮助": "我可以帮你：\n• 智能对话\n• 管理项目\n• 记忆信息\n• 执行任务"
        }
        
        for key, response in responses.items():
            if key in last_msg:
                return response
        
        return f"我收到了: {last_msg[:20]}..."


class ModelRouter:
    """模型路由器"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.provider = config.get("provider", "mock")
        self.model = self._create_model()
    
    def _create_model(self) -> BaseModel:
        provider = self.provider.lower()
        
        if provider == "minimax":
            return MiniMaxModel(self.config)
        elif provider == "openai":
            return OpenAIModel(self.config)
        else:
            return MockModel(self.config)
    
    async def chat(self, messages: List[Dict]) -> str:
        """聊天"""
        return await self.model.chat(messages)
