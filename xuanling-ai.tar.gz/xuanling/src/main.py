"""
玄灵AI - 主入口
"""
import asyncio
import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# 确保路径正确
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.gateway import Gateway, Message
from src.core import Agent
from src.memory import MemoryManager
from src.skills import SkillRegistry
from src.model import ModelRouter
from src.plugins import PluginManager
from src.storage import Database


class XuanlingApp:
    """玄灵AI 应用"""
    
    def __init__(self):
        self.config = self._load_config()
        self.db = None
        self.gateway = None
        self.agent = None
        self.memory = None
        self.model = None
        self.plugins = None
    
    def _load_config(self) -> dict:
        """加载配置"""
        import yaml
        config = {
            "server": {"host": "0.0.0.0", "port": 8000},
            "model": {"provider": "mock", "api_key": ""},
            "memory": {"short_term_limit": 20},
            "database": {"path": "xuanling.db"},
            "plugins": ["feishu"],
            "gateway": {"rate_limit": {"max_requests": 60, "window": 60}}
        }
        
        config_file = Path(__file__).parent.parent / "config.yaml"
        if config_file.exists():
            with open(config_file) as f:
                config.update(yaml.safe_load(f) or {})
        
        # 环境变量覆盖
        if os.getenv("API_KEY"):
            config["model"]["api_key"] = os.getenv("API_KEY")
        
        return config
    
    async def initialize(self):
        """初始化"""
        print("🚀 初始化玄灵AI...")
        
        # 1. 数据库
        print("📦 初始化数据库...")
        self.db = Database(self.config.get("database", {}))
        await self.db.init()
        
        # 2. 模型
        print("🤖 初始化模型...")
        self.model = ModelRouter(self.config.get("model", {}))
        
        # 3. 记忆
        print("🧠 初始化记忆系统...")
        self.memory = MemoryManager(self.config.get("memory", {}))
        await self.memory.init(self.db)
        
        # 4. 技能
        print("🛠️ 加载技能...")
        self.skills = SkillRegistry()
        
        # 5. Agent
        print("✨ 初始化 Agent...")
        self.agent = Agent(
            model=self.model,
            memory=self.memory,
            skills=self.skills,
            config=self.config.get("agent", {"name": "玄灵AI"})
        )
        
        # 6. 插件
        print("🔌 加载插件...")
        self.plugins = PluginManager(self.config.get("plugins", []))
        await self.plugins.on_start()
        
        # 7. Gateway
        print("🌐 启动网关...")
        self.gateway = Gateway(
            agent=self.agent,
            plugins=self.plugins,
            config=self.config.get("gateway", {})
        )
        
        print("✅ 玄灵AI 启动完成!")
        print(f"📍 服务地址: http://{self.config['server']['host']}:{self.config['server']['port']}")


# FastAPI 应用
app = FastAPI(title="玄灵AI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

xuanling_app = None


@app.on_event("startup")
async def startup():
    global xuanling_app
    xuanling_app = XuanlingApp()
    await xuanling_app.initialize()


@app.get("/")
async def root():
    return {"name": "玄灵AI", "version": "1.0.0", "status": "running"}


@app.get("/health")
async def health():
    return {"status": "healthy"}


@app.post("/chat")
async def chat(message: str, user_id: str = "user"):
    """聊天接口"""
    if xuanling_app:
        response = await xuanling_app.gateway.handle_web(message, user_id)
        return response.to_dict()
    return {"message": "系统未初始化"}


@app.get("/memory")
async def get_memory():
    """获取记忆"""
    if xuanling_app:
        memories = await xuanling_app.memory.get_all_memories()
        return {"memories": [m.to_dict() for m in memories]}
    return {"memories": []}


@app.post("/memory")
async def add_memory(title: str, content: str, tags: str = ""):
    """添加记忆"""
    if xuanling_app:
        tag_list = tags.split(",") if tags else []
        memory = await xuanling_app.memory.add_memory(title, content, tag_list)
        if memory:
            return {"status": "ok", "memory": memory.to_dict()}
    return {"status": "error"}


@app.get("/projects")
async def get_projects():
    """获取项目"""
    if xuanling_app:
        return {"projects": await xuanling_app.db.get_projects()}
    return {"projects": []}


@app.post("/projects")
async def create_project(name: str, description: str = "", icon: str = "📁"):
    """创建项目"""
    if xuanling_app:
        project_id = await xuanling_app.db.create_project(name, description, icon)
        return {"status": "ok", "id": project_id}
    return {"status": "error"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
