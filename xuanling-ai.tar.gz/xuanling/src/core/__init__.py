"""
Core - 核心模块
"""
from typing import List, Dict, Any, Optional
import json
import time


class Session:
    """会话"""
    
    def __init__(self, session_id: str, user_id: str):
        self.session_id = session_id
        self.user_id = user_id
        self.created_at = time.time()
        self.updated_at = time.time()
        self.context: Dict = {}
        self.history: List[Dict] = []
    
    def add_turn(self, user: str, assistant: str):
        """添加对话轮次"""
        self.history.append({
            "user": user,
            "assistant": assistant,
            "timestamp": time.time()
        })
        self.updated_at = time.time()
    
    def get_history(self, limit: int = 10) -> List[Dict]:
        """获取历史"""
        return self.history[-limit:]
    
    def set_context(self, key: str, value: Any):
        """设置上下文"""
        self.context[key] = value
    
    def get_context(self, key: str, default: Any = None) -> Any:
        """获取上下文"""
        return self.context.get(key, default)


class SessionManager:
    """会话管理器"""
    
    def __init__(self):
        self.sessions: Dict[str, Session] = {}
    
    def create_session(self, session_id: str, user_id: str) -> Session:
        """创建会话"""
        session = Session(session_id, user_id)
        self.sessions[session_id] = session
        return session
    
    def get_session(self, session_id: str) -> Optional[Session]:
        """获取会话"""
        return self.sessions.get(session_id)
    
    def delete_session(self, session_id: str):
        """删除会话"""
        if session_id in self.sessions:
            del self.sessions[session_id]
    
    def get_or_create(self, session_id: str, user_id: str) -> Session:
        """获取或创建"""
        if session_id not in self.sessions:
            return self.create_session(session_id, user_id)
        return self.sessions[session_id]


class Agent:
    """AI 代理核心"""
    
    def __init__(self, model, memory, skills, config: Dict = None):
        self.name = config.get("name", "玄灵AI")
        self.model = model
        self.memory = memory
        self.skills = skills
        self.config = config or {}
        self.sessions = SessionManager()
        
        # 系统提示词
        self.system_prompt = self._build_system_prompt()
    
    def _build_system_prompt(self) -> str:
        """构建系统提示词"""
        return f"""你是 {self.name}，一个智能 AI 助手。

你的能力：
• 智能对话和问答
• 帮助用户完成各种任务
• 学习和记忆用户偏好

请用友好、专业的方式回复。"""
    
    async def handle(self, message) -> str:
        """处理消息"""
        # 获取对话历史
        history = self.memory.get_recent(5)
        
        # 构建消息
        messages = [{"role": "system", "content": self.system_prompt}]
        
        for h in history:
            messages.append({"role": "user", "content": h.get("user", "")})
            messages.append({"role": "assistant", "content": h.get("assistant", "")})
        
        messages.append({"role": "user", "content": message.content})
        
        # 调用模型
        response = await self.model.chat(messages)
        
        # 保存到记忆
        await self.memory.add_turn(message.content, response)
        
        return response
    
    async def handle_with_context(self, message, context: Dict) -> str:
        """带上下文处理"""
        # 合并上下文到系统提示
        context_prompt = self.system_prompt
        if "project" in context:
            context_prompt += f"\n\n当前项目: {context['project']}"
        
        # 调用模型
        messages = [
            {"role": "system", "content": context_prompt},
            {"role": "user", "content": message.content}
        ]
        
        response = await self.model.chat(messages)
        
        return response


class Config:
    """配置管理"""
    
    def __init__(self, config: Dict = None):
        self.data = config or {}
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置"""
        keys = key.split(".")
        value = self.data
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
        return value if value is not None else default
    
    def set(self, key: str, value: Any):
        """设置配置"""
        keys = key.split(".")
        data = self.data
        for k in keys[:-1]:
            if k not in data:
                data[k] = {}
            data = data[k]
        data[keys[-1]] = value
